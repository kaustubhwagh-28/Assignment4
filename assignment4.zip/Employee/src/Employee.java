
//How can you sort an array of Employee objects by: First Name (ascending), Age (descending), Salary(ascending & descending) using java APIs to perform all the sorting.
//How can you perform a binary search on an array of Employee objects using java APIs?
import java.util.*;

public class Employee implements Comparable<Employee> {
	private String FirstName;
	private int Age;
	private int Salary;

	public Employee(String FirstName, int Age, int Salary) {
		this.FirstName = FirstName;
		this.Age = Age;
		this.Salary = Salary;
	}

	public String getFirstName() {
		return this.FirstName;
	}

	public int getAge() {
		return this.Age;
	}

	public int getSalary() {
		return this.Salary;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee> list = new ArrayList<Employee>();
		Employee x = new Employee("x", 20, 10000);
		Employee y = new Employee("y", 21, 11000);
		Employee z = new Employee("z", 22, 12000);
		Employee a = new Employee("a", 23, 13000);
		list.add(x);
		list.add(y);
		list.add(z);
		list.add(a);
		Collections.sort(list);
		//creating array of employee objects
        Employee[]employees= {x,y,z,a};
        for(int i=0;i<employees.length;i++)
        {
        	System.out.println(employees[i].getAge());
        }
        
        
        //converting to list
        List<Employee> list1 = Arrays.asList(employees);
        System.out.println("using binary search to find the index of the employee object");
        int index = Collections.binarySearch(list1,new Employee("y",21,11000));
        System.out.println("Found at index  " + index);
		System.out.println("after sorting in descending order of age ");
		System.out.println("name age salary ");
		list.forEach(o -> System.out.println(o.getFirstName() + "   " + o.getAge() + "   " + o.getSalary()));
		Collections.sort(list, new SalaryComparator());
		System.out.println("after sorting salary in ascending order");
		System.out.println("name age salary ");
		list.forEach(o -> System.out.println(o.getFirstName() + "   " + o.getAge() + "   " + o.getSalary()));
		Collections.sort(list, new SalaryDescComparator());
		System.out.println("after sorting salary in descending order");
		System.out.println("name age salary ");
		list.forEach(o -> System.out.println(o.getFirstName() + "   " + o.getAge() + "   " + o.getSalary()));
		Collections.sort(list, new FirstNameComparator());
		System.out.println("after sorting by FirstName");
		System.out.println("name age salary ");
		list.forEach(o -> System.out.println(o.getFirstName() + "   " + o.getAge() + "   " + o.getSalary()));
		
		
		
	}

	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		// sorting in descending order
		return o.Age - this.Age;
	}

}
