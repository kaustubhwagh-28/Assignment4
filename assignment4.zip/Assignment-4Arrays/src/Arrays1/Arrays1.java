//1.	Write a program to find the sum of all the elements in an array.
//2.	Write a program that searches for an int an array of int's (use sequential search).
//3.	Write a program that searches for a string in an array of strings (use sequential search).
//4.	Write a program to search for a number in an array using binary search. 
//Note: Do not use any API that is provided by Java, code the logic yourself.
//5.	Write a program to swap alternate elements in an array.
//6.	Write a program to reverse an array into a new array.
//7.	Write a program to reverse an array in place (do not use a 2nd Array).
//8.	Write a program that removes duplicates in a sorted array using a second array.
//9.	Write a program that removes duplicates in a sorted array in place (do not use a 2nd Array)..
//
//10.	What are constant arrays? How do you define them? When are they used?  
//11.	Write a program where input is two sorted arrays of ints. The data from these arrays needs to be put into a larger array (numbers need to be sorted, duplicates are allowed.
//
//12.	What is the correct way to iterate through an array in java? How do you ensure that you do not over-run the length of the array?
//13.	How can you sort an array of integers using java APIs.
//14.	How can you sort an array of Strings (all lowercase) using java APIs. Ascending & descending.
//15.	How can you sort an array of Strings (case in-sensitive sort) using java APIs.
//16.	How can you sort an array of Employee objects by: First Name (ascending), Age (descending), Salary(ascending & descending) using java APIs to perform all the sorting.
//17.	How can you perform a binary search on an array of longs using java APIs.
//18.	How can you perform a binary search on an array of Employee objects using java APIs?
//19.	Write a program to implement selection sort.
//20.	Write a program to implement bubble sort.
//21.	Write a program to multiply two matrices.
//22.	Write a program that will output all possible permutations and combinations of an inputted string.
//
//
package Arrays1;

import java.util.*;

public class Arrays1 {
	private final String inputstring;
	private StringBuilder output = new StringBuilder();

	Arrays1(final String str) {

		inputstring = str;
	}

	static int MAX = 100;

	public static int ArraySum(int arr[]) {
		System.out.println("Calculating sum of elements in array");
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}
		return sum;
	}

	public static int SequentialSearch(int arr[], int no) {
		for (int index = 0; index < arr.length; index++) {
			if (arr[index] == no) {
				// returning the index where number is found
				return index;
			}
		}
		System.out.println("not present");
		return -1;
	}

	public static int SequentialStringSearch(String arr[], String string) {
		for (int index = 0; index < arr.length; index++) {
			if (arr[index].equals(string)) {
				return index;
			}
		}
		System.out.println("not present");
		return -1;
	}

	public static int[] AlternateNumbersSwap(int arr[]) {
		int temp = 0;
		// as the alternate numbers needs to be swapped
		for (int i = 0; i < arr.length - 2; i++) {
			temp = arr[i];
			arr[i] = arr[i + 2];
			arr[i + 2] = temp;
		}
		return arr;
	}

	public static int[] ReverseArrayUsingTwoArrays(int[] arr) {
		int length = arr.length;
		int brr[] = new int[length];
		int i = 0;
		// traversing from backward direction.
		// putting the element into another array
		for (int j = length - 1; j >= 0; j--)

		{
			brr[i] = arr[j];
			i++;
		}
		System.out.println();
		return brr;
	}

	public static int[] ReverseArrayUsingOneArray(int[] arr) {
		int end = arr.length - 1;

		int start = 0;
		int temp;
		while (start <= end) {
			temp = arr[start];
			arr[start] = arr[end];
			arr[end] = arr[start];
			start++;
			end--;

		}
		System.out.println();
		return arr;

	}

	public static void caseInsensetivesort(String[] arr) {
		List<String> list = Arrays.asList(arr); /// converting to list
		Collections.sort(list, String.CASE_INSENSITIVE_ORDER);
		System.out.println(list);
		System.out.println();
	}

	public static int removeDuplicates(int arr[], int n) {

		// Return, if array is empty
		// or contains a single element
		if (n == 0 || n == 1)

			return n;

		int[] temp = new int[n];

		// Start traversing elements
		int j = 0;
		for (int i = 0; i < n - 1; i++) {
			// If current element is not equal
			// to next element then store that
			// current element
			if (arr[i] != arr[i + 1]) {
				temp[j++] = arr[i];
			}
		}
		// Store the last element as whether
		// it is unique or repeated, it hasn't
		// stored previously
		temp[j++] = arr[n - 1];

		// Modify original array
		for (int i = 0; i < j; i++) {
			arr[i] = temp[i];
		}

		return j;
	}

	public static int removeDuplicatesWithoutUsingSecondArray(int arr[], int n) {

		// Return, if array is empty
		// or contains a single element
		if (n == 0 || n == 1)

			return n;

		// for keeping track of index of next unique elements
		int j = 0;

		for (int i = 0; i < n - 1; i++) {
			// If current element is not equal
			// to next element then store that
			// current element
			if (arr[i] != arr[i + 1]) {
				arr[j++] = arr[i];
			}
		}

		// Store the last element as whether
		// it is unique or repeated, it hasn't
		// stored previously
		arr[j++] = arr[n - 1];

		return j;
	}

	public static void SortingUsingApi(int[] arr) {
		Arrays.sort(arr);
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}

	public static void StringArraySortingUsingApi(String arr[]) {
		Arrays.sort(arr, Collections.reverseOrder());
		System.out.println("descending order");
		System.out.println();
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
		System.out.println("ascending order");
		Arrays.sort(arr);
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	public static void SelectionSort(int arr[]) {

		int n = arr.length;

		// One by one move boundary of unsorted subarray
		for (int i = 0; i < n - 1; i++) {
			// Find the minimum element in unsorted array
			int min_idx = i;
			for (int j = i + 1; j < n; j++) {
				if (arr[j] < arr[min_idx]) {
					min_idx = j;
				}
			}
			// Swap the found minimum element with the first
			// element
			int temp = arr[min_idx];
			arr[min_idx] = arr[i];
			arr[i] = temp;
		}
		for (int i = 0; i < n; i++) {
			System.out.print(arr[i] + " ");
		}
	}

	public static void bubblesort(int arr[]) {
		int temp = 0;
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = 0; j < arr.length - i - 1; j++) {
				if (arr[j] > arr[j + 1]) {
					temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
			}
		}
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}

	}

	static void printMatrix(int M[][], int rowSize, int colSize) {
		for (int i = 0; i < rowSize; i++) {
			for (int j = 0; j < colSize; j++)
				System.out.print(M[i][j] + " ");

			System.out.println();
		}
	}

//Function to multiply two matrices A[][] and B[][]
	static void multiplyMatrix(int row1, int col1, int A[][], int row2, int col2, int B[][]) {

		int i, j, k;

// Matrix to store the result
		int C[][] = new int[MAX][MAX];

// Check if multiplication is Possible
		if (row2 != col1) {
			System.out.println("Not Possible");
			return;
		}

// Multiply the two
		for (i = 0; i < row1; i++) {
			for (j = 0; j < col2; j++) {
				C[i][j] = 0;
				for (k = 0; k < row2; k++)
					C[i][j] += A[i][k] * B[k][j];
			}
		}

// Print the result
		System.out.println();
		System.out.println("Resultant Matrix: ");
		printMatrix(C, row1, col2);
	}

	public static String swapString(String a, int i, int j) {
		char[] b = a.toCharArray();
		char ch;
		ch = b[i];
		b[i] = b[j];
		b[j] = ch;
		return String.valueOf(b);
	}

	public static void generatePermutation(String str, int start, int end) {
		// Prints the permutations
		if (start == end - 1)
			System.out.println(str);
		else {
			for (int i = start; i < end; i++) {
				// Swapping the string by fixing a character
				str = swapString(str, start, i);
				// Recursively calling function generatePermutation() for rest of the characters
				generatePermutation(str, start + 1, end);
				// Backtracking and swapping the characters again.
				str = swapString(str, start, i);
			}
		}
	}

	public void combination() {
		combine(0);
	}

	private void combine(int start) {

		for (int i = start; i < inputstring.length(); ++i) {
			// putting the numbers till it exceds the length
			output.append(inputstring.charAt(i));
			System.out.println(output);

			if (i < inputstring.length())
				combine(i + 1);
			// reducing the length by 1 of output which is a string builder
			output.setLength(output.length() - 1);
		}

	}

	public static int BinarySearch(int arr[], int start, int end, int no) {
		if (end >= start) {
			int mid = start + (end - start) / 2;

			// if mid elemnt contains the number return it
			if (arr[mid] == no) {
				return mid;
			}

			if (arr[mid] > no) {
				// if mid element greater than number.we search in left side from start to mid
				return BinarySearch(arr, start, mid - 1, no);
			}
			// else we search in right side from mid to end
			return BinarySearch(arr, mid + 1, end, no);
		}

		return -1;
	}

	public static void mergeArrays(int[] arr1, int[] arr2, int n1, int n2, int[] arr3) {
		int i = 0, j = 0, k = 0;

// Traverse both array
		while (i < n1 && j < n2) {
// Check if current element of first
// array is smaller than current element
// of second array. If yes, store first
// array element and increment first array
// index. Otherwise do same with second array
			if (arr1[i] < arr2[j])
				arr3[k++] = arr1[i++];
			else
				arr3[k++] = arr2[j++];
		}

// Store remaining elements of first array
		while (i < n1)
			arr3[k++] = arr1[i++];

// Store remaining elements of second array
		while (j < n2)
			arr3[k++] = arr2[j++];

		System.out.println("After merging");
		for (i = 0; i < n1 + n2; i++) {
			System.out.print(arr3[i] + " ");
		}
	}

	public static void main(String args[]) {
		Scanner read = new Scanner(System.in);
		Scanner s = new Scanner(System.in);
		int[] arr = { 1, 3, 11, 90, 56 };
		System.out.println(ArraySum(arr));
		System.out.println(SequentialSearch(arr, 90));
		int end = arr.length - 1;
		System.out.println(BinarySearch(arr, 0, end, 90));
		int arr4[] = { 1, 2, 2, 3, 4, 4, 4, 5, 5 };
		int size = arr4.length;
		int[] arr100 = { 1, 2, 2, 3, 4, 4, 4, 5, 5 };
		int y = removeDuplicates(arr4, size);

		for (int i = 0; i < y; i++) {
			System.out.print(arr4[i] + " ");
		}
		System.out.println();
		int z = removeDuplicatesWithoutUsingSecondArray(arr100, size);

		for (int i = 0; i < z; i++) {
			System.out.print(arr4[i] + " ");
		}
		System.out.println();

		String[] arr1 = { "hello", "hi", "how", "are", "you" };
		System.out.println(SequentialStringSearch(arr1, "how"));
		System.out.println("Reversing array using two array");
		int result[] = ReverseArrayUsingTwoArrays(arr);
		for (int i = 0; i < result.length; i++) {
			System.out.print(result[i] + " ");
		}
		System.out.println();
		System.out.println("reversing array without using two array");
		int result100[] = ReverseArrayUsingOneArray(arr);
		for (int i = 0; i < result.length; i++) {
			System.out.print(result[i] + " ");
		}
		System.out.println();

		String arr3[] = { "apple", "ball", "cat", "dog", "elephant" };
		StringArraySortingUsingApi(arr3);
		int[] arr9 = { 100, 80, 70, 30, 20, 10 };
		System.out.println("using Bubble sort");
		bubblesort(arr9);
		System.out.println("using selection sort");
		SelectionSort(arr9);
		System.out.println("using binary search");
		System.out.println("index of 100 is " // using java API for binary search
				+ Arrays.binarySearch(arr9, 100));
		System.out.println("Index of 100 without by calling defined binary search function");
		System.out.println(BinarySearch(arr9, 0, 6, 100));

		System.out.println("Matrix multiplication");
		int row1, col1, row2, col2, i, j;
		int A[][] = new int[MAX][MAX];
		int B[][] = new int[MAX][MAX];

		// Read size of Matrix A from user
		System.out.print("Enter the number of " + "rows of First Matrix: ");
		row1 = read.nextInt();
		System.out.println(row1);
		System.out.print("Enter the number of " + "columns of First Matrix: ");
		col1 = read.nextInt();
		System.out.println(col1);

		// Read the elements of Matrix A from user
		System.out.println("Enter the elements " + "of First Matrix: ");
		for (i = 0; i < row1; i++) {
			for (j = 0; j < col1; j++) {
				System.out.print("A[" + i + "][" + j + "]: ");
				A[i][j] = read.nextInt();
				System.out.println(A[i][j]);
			}
		}

		// Read size of Matrix B from user
		System.out.print("Enter the number of " + "rows of Second Matrix: ");
		row2 = read.nextInt();
		System.out.println(row2);
		System.out.print("Enter the number of " + "columns of Second Matrix: ");
		col2 = read.nextInt();
		System.out.println(col2);

		// Read the elements of Matrix B from user
		System.out.println("Enter the elements " + "of Second Matrix: ");
		for (i = 0; i < row2; i++) {
			for (j = 0; j < col2; j++) {
				System.out.print("A[" + i + "][" + j + "]: ");
				B[i][j] = read.nextInt();
				System.out.println(B[i][j]);
			}
		}

		// Print the Matrix A
		System.out.println();
		System.out.println("First Matrix: ");
		printMatrix(A, row1, col1);

		// Print the Matrix B
		System.out.println();
		System.out.println("Second Matrix: ");
		printMatrix(B, row2, col2);

		// Find the product of the 2 matrices
		multiplyMatrix(row1, col1, A, row2, col2, B);
		System.out.println("enter the string you want to enter");
		String str = read.next();
		int len = str.length();
		System.out.println("All the permutations of the string are: ");
		generatePermutation(str, 0, len);
		System.out.println("All the combinations are");
		Arrays1 obj = new Arrays1(str);
		obj.combination();
		String[] casesinsensitive = { "A", "a", "f", "FOR", "Hello", "hello" };
		caseInsensetivesort(casesinsensitive);
		int arr8[] = { 1, 2, 3, 4, 5 };
		int arr90[] = { 1, 5, 6, 7, 8, 8 };
		int size1 = arr8.length;
		int size2 = arr9.length;
		int result10[] = new int[size1 + size2];
		mergeArrays(arr8, arr90, size1, size2, result10);
	}
}
