//1.	Write a program to find the sum of all the elements in an array.
//2.	Write a program that searches for an int an array of int's (use sequential search).
//3.	Write a program that searches for a string in an array of strings (use sequential search).
//4.	Write a program to search for a number in an array using binary search. 
//Note: Do not use any API that is provided by Java, code the logic yourself.
//5.	Write a program to swap alternate elements in an array.
//6.	Write a program to reverse an array into a new array.
//7.	Write a program to reverse an array in place (do not use a 2nd Array).
//8.	Write a program that removes duplicates in a sorted array using a second array.
//9.	Write a program that removes duplicates in a sorted array in place (do not use a 2nd Array)..
//
//10.	What are constant arrays? How do you define them? When are they used?  
//11.	Write a program where input is two sorted arrays of ints. The data from these arrays needs to be put into a larger array (numbers need to be sorted, duplicates are allowed.
//
//12.	What is the correct way to iterate through an array in java? How do you ensure that you do not over-run the length of the array?
//13.	How can you sort an array of integers using java APIs.
//14.	How can you sort an array of Strings (all lowercase) using java APIs. Ascending & descending.
//15.	How can you sort an array of Strings (case in-sensitive sort) using java APIs.
//16.	How can you sort an array of Employee objects by: First Name (ascending), Age (descending), Salary(ascending & descending) using java APIs to perform all the sorting.
//17.	How can you perform a binary search on an array of longs using java APIs.
//18.	How can you perform a binary search on an array of Employee objects using java APIs?
//19.	Write a program to implement selection sort.
//20.	Write a program to implement bubble sort.
//21.	Write a program to multiply two matrices.
//22.	Write a program that will output all possible permutations and combinations of an inputted string.
//
//
import java.util.*;
 class Arrays1 {
	public static int ArraySum(int arr[])
	{
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		return sum;
	}
	public static int SequentialSearch(int arr[],int no)
	{
		for(int index=0;index<arr.length;index++)
		{
			if(arr[index]==no)
			{
				return index;
			}
		}
		System.out.println("not present");
		return -1;
	}
	public static int SequentialStringSearch(String arr[],String string)
	{
		for(int index=0;index<arr.length;index++)
		{
			if(arr[index].equals(string))
			{
				return index;
			}
		}
		System.out.println("not present");
		return -1;
	}
	public static int [] AlternateNumbersSwap(int arr[])
	{
		int temp=0;
		for(int i=0;i<arr.length-2;i++)
		{
			temp=arr[i];
			arr[i]=arr[i+2];
			arr[i+2]=temp;
		}
		return arr;
	}
	public static int[] ReverseArrayUsingTwoArrays(int []arr)
	{
		int length=arr.length;
		int brr[]=new int[length];
	    int i=0;
		for(int j=length-1;j>=0;j--)
			
		{
			brr[i]=arr[j];
			i++;
		}
		return brr;
	}

public static int[] ReverseArrayUsingOneArray(int []arr)
{
	int end=arr.length-1;
	
	
    int start=0;
    int temp;
	while(start <=end)
	{
		temp=arr[start];
		arr[start]=arr[end];
		arr[end]=arr[start];
		start++;
		end--;
		
	}
	return arr;

	}
public static int RemovingDuplicatesUsingTwoArray(int arr[],int n)
{
	

		if (n==0 || n==1)
		return n;

		int temp[] = new int[n];

		int j = 0;
		int i;
		for (i=0; i<n-1; i++)
		{
		if (arr[i] != arr[i+1])
		temp[j++] = arr[i];
		temp[j++] = arr[n-1];
		}
		for (i=0; i<j; i++)
		{
		arr[i] = temp[i];
		}
		return j;
}
	public static void SortingUsingApi(int []arr)
	{
	Arrays.sort(arr);
	for(int i=0;i< arr.length;i++)
	{
		System.out.print(arr[i]+" ");
	}
	}
	public static void StrinArraySortingUsingApi(String arr[])
	{
		Arrays.sort(arr,Collections.reverseOrder());
		System.out.println("descending order");
	    for(int i=0;i<arr.length;i++)
	    {
	    	System.out.print(arr[i] +" ");
	    }
	    System.out.println("ascending order");
	    Arrays.sort(arr);
	    for(int i=0;i<arr.length;i++)
	    {
	    	System.out.print(arr[i] +" ");
	    }
	}
public static void main(String args[])
{
	System.out.println("ji");
	int []arr= {1,3,11,90,56};
	System.out.println(ArraySum(arr));
	System.out.println(SequentialSearch(arr,90));
	String []arr1= {"hello","hi","how","are","you"};
	System.out.println(SequentialStringSearch(arr1,"how"));
	int result[]=ReverseArrayUsingTwoArrays(arr);
	for(int i=0;i<result.length;i++)
	{
		System.out.print(result[i] + " ");
	}
	int brr[]= {2,2,2,2,33,33,44,55};
	int n =  RemovingDuplicatesUsingTwoArray(brr,8);
    for(int i=0;i<n;i++)
    {
    	System.out.print(brr[i]+" ");
    }
    String arr3[]= {"apple","ball","cat","dog","elephant"};
    Arrays.sort(arr3,Collections.reverseOrder());
    for(int i=0;i<arr3.length;i++)
    {
    	System.out.print(arr3[i] +" ");
    }
}
}

